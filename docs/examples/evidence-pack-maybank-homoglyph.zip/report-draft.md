# Review draft: xn--mybank-verify-w1k[.]example

Not submitted. Analyst verification is required.

Synthetic: True
Priority score: 80/100
Verdict: suspicious

Reasons:
- Brand token in non-official domain
- Lure keywords: verify
- Unicode label; inspect A-label and visual spelling
- Registered 2 days before evaluation

Analyst note:
Cyrillic а (U+0430) replaces Latin a in maybank, plus verify and a 2-day-old registration. Escalating for a page capture from the authorised sandbox before any report.

Registration and hosting metadata are supplied observations, not independently verified. Certificate appearance does not prove maliciousness.
